/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.accountingsystem;

/**
 *
 * @author userlab3
 */
public class AccountingSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
